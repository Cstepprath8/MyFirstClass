﻿// See https://aka.ms/new-console-template for more information
using System;
using MyFirstClass;

namespace MyFirstClass
{
    internal class Program
    { 
        static void Main(String[] args)
        {
            ProjectStoel rodeStoel = new ProjectStoel("rood", 60);
            Console.WriteLine(rodeStoel.echoKleur());
            Console.WriteLine("De stoel heeft een zithoogte van: " + rodeStoel.GetOpgegevenZithoogte());
            rodeStoel.verstellen(70);
            Console.WriteLine("ZitHoogte na Verstelling: " + rodeStoel.GetOpgegevenZithoogte());

        }
    }

}



