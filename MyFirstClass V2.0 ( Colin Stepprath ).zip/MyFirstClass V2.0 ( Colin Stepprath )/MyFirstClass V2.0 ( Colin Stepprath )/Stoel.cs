﻿using System;
using MyFirstClass;

namespace MyFirstClass
{
    internal class ProjectStoel
    {
        //Eigenschappen
        private string Kleur;
        private int Zithoogte;

        //Contribuut
        public ProjectStoel(string OpgegevenKleur, int OpgegevenZithoogte)
        {
            Kleur = OpgegevenKleur;
            Zithoogte = OpgegevenZithoogte;
        }


        //Handeling
        public string echoKleur()
        {
            return "De kleur van de stoel is: " + Kleur;
        }

        public int GetOpgegevenZithoogte()
        {
            return  Zithoogte;
        }

        public void verstellen(int hoogte)
        {
            Zithoogte = hoogte;
        }
    }



}